function toggleMenu() {
console.log('toggleMenu called');
const headA = document.querySelector('.head-a');
const hamburger = document.querySelector('.hamburger-menu');
console.log('Menu elements found:', {
headA: !!headA,
hamburger: !!hamburger,
headAClasses: headA ? headA.className : 'not found',
hamburgerClasses: hamburger ? hamburger.className : 'not found'
});
if (headA) {
headA.classList.toggle('show-menu');
if (hamburger) {
hamburger.classList.toggle('active');
}
console.log('Menu toggled. Show-menu class:', headA.classList.contains('show-menu'));
} else {
console.error('Menu element not found - header may not be loaded yet');
setTimeout(function() {
const retryHeadA = document.querySelector('.head-a');
const retryHamburger = document.querySelector('.hamburger-menu');
if (retryHeadA) {
retryHeadA.classList.toggle('show-menu');
if (retryHamburger) {
retryHamburger.classList.toggle('active');
}
console.log('Menu toggled on retry');
} else {
console.error('Menu still not found after retry');
}
}, 100);
}
}
function initializeMenuEvents() {
let touchTimeout;
function initializeMobileDropdowns() {
const dropdowns = document.querySelectorAll('.head-a .dropdown');
dropdowns.forEach(dropdown => {
const mainLink = dropdown.querySelector('a');
const dropdownContent = dropdown.querySelector('.dropdown-content');
if (mainLink && dropdownContent) {
mainLink.addEventListener('touchstart', handleMobileTouchStart, { passive: true });
dropdown.addEventListener('touchend', handleMobileTouchEnd, { passive: true });
dropdown.addEventListener('mouseleave', handleMobileMouseLeave, { passive: true });
const dropdown2Items = dropdownContent.querySelectorAll('.dropdown2');
dropdown2Items.forEach(dropdown2 => {
const secondaryLink = dropdown2.querySelector('a');
const dropdown2Content = dropdown2.querySelector('.dropdown2-content');
if (secondaryLink && dropdown2Content) {
secondaryLink.addEventListener('touchstart', handleMobileTouch2Start, { passive: true });
dropdown2.addEventListener('touchend', handleMobileTouch2End, { passive: true });
dropdown2.addEventListener('mouseleave', handleMobileMouseLeave2, { passive: true });
}
});
}
});
}
function handleMobileTouchStart(event) {
const hamburger = document.querySelector('.hamburger-menu');
if (!hamburger || getComputedStyle(hamburger).display === 'none') {
return;
}
const dropdown = event.target.closest('.dropdown');
document.querySelectorAll('.dropdown.mobile-hover, .dropdown2.mobile-hover').forEach(item => {
if (item !== dropdown) {
item.classList.remove('mobile-hover');
}
});
dropdown.classList.add('mobile-hover');
}
function handleMobileTouchEnd(event) {
const hamburger = document.querySelector('.hamburger-menu');
if (!hamburger || getComputedStyle(hamburger).display === 'none') {
return;
}
}
function handleMobileMouseLeave(event) {
const dropdown = event.currentTarget;
dropdown.classList.remove('mobile-hover');
}
function handleMobileTouch2Start(event) {
const hamburger = document.querySelector('.hamburger-menu');
if (!hamburger || getComputedStyle(hamburger).display === 'none') {
return;
}
const dropdown2 = event.target.closest('.dropdown2');
document.querySelectorAll('.dropdown2.mobile-hover').forEach(item => {
if (item !== dropdown2) {
item.classList.remove('mobile-hover');
}
});
dropdown2.classList.add('mobile-hover');
}
function handleMobileTouch2End(event) {
const hamburger = document.querySelector('.hamburger-menu');
if (!hamburger || getComputedStyle(hamburger).display === 'none') {
return;
}
}
function handleMobileMouseLeave2(event) {
const dropdown2 = event.currentTarget;
dropdown2.classList.remove('mobile-hover');
}
document.addEventListener('touchstart', function(event) {
const menu = document.querySelector('.head-a');
const hamburger = document.querySelector('.hamburger-menu');
if (menu && menu.classList.contains('show-menu')) {
const touchedDropdown = event.target.closest('.dropdown');
const touchedDropdown2 = event.target.closest('.dropdown2');
if (!touchedDropdown) {
document.querySelectorAll('.dropdown.mobile-hover').forEach(dropdown => {
dropdown.classList.remove('mobile-hover');
});
}
if (!touchedDropdown2) {
document.querySelectorAll('.dropdown2.mobile-hover').forEach(dropdown2 => {
dropdown2.classList.remove('mobile-hover');
});
}
}
if (menu && menu.classList.contains('show-menu')) {
if (!menu.contains(event.target) && !hamburger.contains(event.target)) {
menu.classList.remove('show-menu');
if (hamburger) {
hamburger.classList.remove('active');
}
document.querySelectorAll('.dropdown.mobile-hover, .dropdown2.mobile-hover').forEach(item => {
item.classList.remove('mobile-hover');
});
}
}
}, { passive: true });
document.addEventListener('click', function(event) {
const menu = document.querySelector('.head-a');
const hamburger = document.querySelector('.hamburger-menu');
if (menu && menu.classList.contains('show-menu')) {
if (!menu.contains(event.target) && !hamburger.contains(event.target)) {
menu.classList.remove('show-menu');
if (hamburger) {
hamburger.classList.remove('active');
}
document.querySelectorAll('.dropdown.mobile-hover, .dropdown2.mobile-hover').forEach(item => {
item.classList.remove('mobile-hover');
});
}
}
});
initializeMobileDropdowns();
const headerContainer = document.getElementById('header-container');
if (headerContainer) {
const observer = new MutationObserver(function(mutations) {
mutations.forEach(function(mutation) {
if (mutation.type === 'childList' && mutation.addedNodes.length > 0) {
const headerAdded = Array.from(mutation.addedNodes).some(node =>
node.nodeType === 1 && (node.querySelector('.head-a') || node.classList?.contains('head-a'))
);
if (headerAdded) {
setTimeout(initializeMobileDropdowns, 100);
}
}
});
});
observer.observe(headerContainer, { childList: true, subtree: true });
}
}
document.addEventListener('DOMContentLoaded', function() {
initializeMenuEvents();
const observer = new MutationObserver(function(mutations) {
mutations.forEach(function(mutation) {
if (mutation.type === 'childList') {
const hamburger = document.querySelector('.hamburger-menu');
if (hamburger && !hamburger.hasAttribute('data-listener-added')) {
hamburger.removeAttribute('onclick');
hamburger.addEventListener('click', toggleMenu);
hamburger.setAttribute('data-listener-added', 'true');
console.log('Mobile menu initialized');
observer.disconnect();
}
}
});
});
const headerContainer = document.getElementById('header-container');
if (headerContainer) {
observer.observe(headerContainer, { childList: true, subtree: true });
}
setTimeout(function() {
const hamburger = document.querySelector('.hamburger-menu');
if (hamburger && !hamburger.hasAttribute('data-listener-added')) {
hamburger.removeAttribute('onclick');
hamburger.addEventListener('click', toggleMenu);
hamburger.setAttribute('data-listener-added', 'true');
console.log('Mobile menu initialized (fallback)');
}
}, 1000);
});
window.toggleMenu = toggleMenu;