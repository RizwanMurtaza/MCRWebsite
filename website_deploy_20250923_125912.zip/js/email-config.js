/**
* MCR Solicitors Email Service Configuration
* Production configuration for email service integration
*/
window.EmailServiceConfig = {
API_BASE: 'https:
APP_ID: 'mcr-solicitors-web',
ADMIN_URL: 'https:
ENVIRONMENT: 'production'
};
