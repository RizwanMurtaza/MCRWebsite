/**
* Header Menu JavaScript
* Handles mobile menu toggle and dropdown interactions
*/
function toggleMenu() {
const headA = document.querySelector('.head-a');
const hamburger = document.querySelector('.hamburger-menu');
const body = document.body;
if (headA) {
headA.classList.toggle('show-menu');
if (hamburger) {
hamburger.classList.toggle('active');
}
if (headA.classList.contains('show-menu')) {
body.classList.add('menu-open');
} else {
body.classList.remove('menu-open');
}
}
}
document.addEventListener('click', function(event) {
const headA = document.querySelector('.head-a');
const hamburger = document.querySelector('.hamburger-menu');
if (headA && headA.classList.contains('show-menu')) {
if (!headA.contains(event.target) && !hamburger.contains(event.target)) {
headA.classList.remove('show-menu');
if (hamburger) {
hamburger.classList.remove('active');
}
}
}
});
document.addEventListener('click', function(event) {
const headA = document.querySelector('.head-a');
if (event.target.matches('.head-a.show-menu::before')) {
headA.classList.remove('show-menu');
}
});
document.addEventListener('DOMContentLoaded', function() {
if (window.innerWidth <= 767) {
const dropdowns = document.querySelectorAll('.dropdown');
dropdowns.forEach(dropdown => {
const link = dropdown.querySelector('> a');
link.addEventListener('click', function(e) {
const hasSubmenu = dropdown.querySelector('.dropdown-content');
if (hasSubmenu) {
e.preventDefault();
dropdown.classList.toggle('active');
dropdowns.forEach(otherDropdown => {
if (otherDropdown !== dropdown) {
otherDropdown.classList.remove('active');
}
});
}
});
});
const dropdown2s = document.querySelectorAll('.dropdown2');
dropdown2s.forEach(dropdown2 => {
const link = dropdown2.querySelector('> a');
link.addEventListener('click', function(e) {
const hasSubmenu = dropdown2.querySelector('.dropdown2-content');
if (hasSubmenu) {
e.preventDefault();
dropdown2.classList.toggle('active');
}
});
});
}
});
let resizeTimer;
window.addEventListener('resize', function() {
clearTimeout(resizeTimer);
resizeTimer = setTimeout(function() {
const headA = document.querySelector('.head-a');
const hamburger = document.querySelector('.hamburger-menu');
if (window.innerWidth > 767) {
if (headA) {
headA.classList.remove('show-menu');
}
if (hamburger) {
hamburger.classList.remove('active');
}
document.querySelectorAll('.dropdown').forEach(dropdown => {
dropdown.classList.remove('active');
});
}
}, 250);
});
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
anchor.addEventListener('click', function (e) {
e.preventDefault();
const target = document.querySelector(this.getAttribute('href'));
if (target) {
target.scrollIntoView({
behavior: 'smooth',
block: 'start'
});
const headA = document.querySelector('.head-a');
if (headA && headA.classList.contains('show-menu')) {
headA.classList.remove('show-menu');
}
}
});
});